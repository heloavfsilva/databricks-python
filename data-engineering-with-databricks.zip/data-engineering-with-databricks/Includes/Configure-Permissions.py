# Databricks notebook source
spark.sql("GRANT CREATE ON CATALOG TO users")

# COMMAND ----------

# spark.sql("GRANT CREATE CATALOG ON METASTORE TO `account users`;")
