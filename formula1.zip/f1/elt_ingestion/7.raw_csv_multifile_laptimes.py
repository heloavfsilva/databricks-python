# Databricks notebook source
# MAGIC %md
# MAGIC ####Ingest pitstops csv multi-file files
# MAGIC 1. Read the csv files using spark dataframe reader
# MAGIC 1. Manipulate the columns (rename, add, drop)
# MAGIC 1. Save as parquet file and validate 

# COMMAND ----------

from pyspark.sql.types import StructType, StructField, IntegerType, StringType, DateType, DoubleType
from pyspark.sql.functions import col, concat, current_timestamp, lit

# COMMAND ----------

# MAGIC %md
# MAGIC #####1. Read the csv multi-file using spark dataframe reader

# COMMAND ----------

display(dbutils.fs.ls('/mnt/f1accstorage/raw/lap_times'))

# COMMAND ----------

schema_laptimes= StructType(fields=[StructField("raceId", IntegerType() ,False),
                                    StructField("driverId", IntegerType() ,False),
                                    StructField("lap", IntegerType() ,False),
                                    StructField("position", IntegerType() ,False),
                                    StructField("time", StringType() ,False),
                                    StructField("miliseconds", IntegerType() ,False)                                                                 
                                    ])

# COMMAND ----------

df_laptimes = spark.read \
    .schema(schema_laptimes) \
    .csv("/mnt/f1accstorage/raw/lap_times/lap_times_split*.csv")
display(df_laptimes)

# COMMAND ----------

# MAGIC %md
# MAGIC #####2. Manipulate the columns (rename, add, drop)

# COMMAND ----------

df_final = df_laptimes.withColumnRenamed("driverId", "driver_id") \
    .withColumnRenamed("raceId", "race_id") \
    .withColumn("load_date", current_timestamp())

# COMMAND ----------

# MAGIC %md
# MAGIC #####3. Save as parquet file and validate 

# COMMAND ----------

df_final.write.mode("overwrite").parquet('/mnt/f1accstorage/raw/laptimes')

# COMMAND ----------

# MAGIC %fs
# MAGIC ls /mnt/f1accstorage/raw/laptimes

# COMMAND ----------

dbutils.notebook.exit("Success")