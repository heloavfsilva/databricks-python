# Databricks notebook source
# MAGIC %md
# MAGIC ####Ingest Races File
# MAGIC #####Read the csv file using spark dataframe reader
# MAGIC 1. import types
# MAGIC 1. check the types and define schema
# MAGIC 1. read the csv
# MAGIC 1. rename the columns
# MAGIC 1. add timestamp and env
# MAGIC 1. delete file in case it exists
# MAGIC 1. write it as parquet partitioned
# MAGIC 1. validate if the parquet file was generated
# MAGIC
# MAGIC pre-work:
# MAGIC 1. create app registration and save the app ID as client ID and Tenant ID
# MAGIC 1. create a key for the app and save the value as client secret
# MAGIC 1. create the key vault in azure
# MAGIC 1. create the secretScope in databricks
# MAGIC 1. assign role 'Storage Blob Data Contributor' to the app registred
# MAGIC 1. setup the variables in the python function to access it and mount the storage

# COMMAND ----------

# MAGIC %md
# MAGIC ####1. import types

# COMMAND ----------

from pyspark.sql.types import StructType, StructField, IntegerType, StringType, DoubleType
from pyspark.sql.functions import col
from pyspark.sql.functions import current_timestamp, lit, to_timestamp, concat
from pathlib import Path
import os

# COMMAND ----------

# MAGIC %md
# MAGIC ####2. check the types and define schema

# COMMAND ----------

# check for the file in the dbfs
display(dbutils.fs.ls("mnt/f1accstorage/raw"))

# COMMAND ----------

#check the file data types 
races_stg = spark.read.option("header",True).csv("/mnt/f1accstorage/raw/races.csv")
races_stg.describe().show()
display(races_stg)

# COMMAND ----------

#define the schema structure
races_schema = StructType(fields=[StructField("raceId", IntegerType(), False),
                                     StructField("year", IntegerType(), True),
                                     StructField("round", IntegerType(), True),
                                     StructField("circuitId", IntegerType(), True),
                                     StructField("name", StringType(), True),
                                     StructField("date", StringType(), True),
                                     StructField("time", StringType(), True),
                                     StructField("url", StringType(), True)                           
                                     
])

# COMMAND ----------

#read the file with the schema applied
races_df = spark.read\
    .option("header",True)\
    .schema(races_schema)\
    .csv("/mnt/f1accstorage/raw/races.csv")
display(races_df)

# COMMAND ----------

# check the file schema
races_df.printSchema()

# COMMAND ----------

#you can use the columns names directly however the limitation is if any manipulation is required
#circuits_selected_df = circuits_df.select("circuitId","circuitRef","name", "location", "country", "lat", "lng", "alt")

# COMMAND ----------

#recommended if you want to manipulate
races_selected_df = races_df.select(col("raceId"), col("year"), col("round"), col("circuitId"), 
                                          col("name"), col("date"), col("time"))

# COMMAND ----------

display(races_selected_df)

# COMMAND ----------

races_renamed_df = races_selected_df.withColumnRenamed("raceId","race_id") \
    .withColumnRenamed("year","race_year") \
    .withColumnRenamed("circuitId","circuit_id")

# COMMAND ----------

display(races_renamed_df)

# COMMAND ----------

races_timestamp_df = races_renamed_df.withColumn("load_date", current_timestamp()) \
    .withColumn("env",lit("raw")) \
    .withColumn("race_timestamp", to_timestamp(concat(col('date'), lit(' '), col('time')), 'yyyy-MM-dd HH:mm:ss'))

# COMMAND ----------

try:
    dbutils.fs.rm("mnt/f1accstorage/raw/races", True)
except FileNotFoundError:
    pass

# COMMAND ----------

#races_timestamp_df.write.parquet("mnt/f1accstorage/raw/races")
races_timestamp_df.write.mode('overwrite').partitionBy('race_year').parquet('mnt/f1accstorage/raw/races')

# COMMAND ----------

# MAGIC %fs
# MAGIC ls /mnt/f1accstorage/raw/races

# COMMAND ----------

df = spark.read.parquet("/mnt/f1accstorage/raw/races")

# COMMAND ----------

display(df)

# COMMAND ----------

dbutils.notebook.exit("Success")