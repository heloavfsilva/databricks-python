# Databricks notebook source
# MAGIC %md
# MAGIC ####Ingest results json file
# MAGIC 1. Read the json file using spark dataframe reader
# MAGIC 1. Manipulate the columns (rename, add, drop)
# MAGIC 1. Save as parquet file and validate 

# COMMAND ----------

from pyspark.sql.types import StructType, StructField, IntegerType, StringType, DateType, DoubleType
from pyspark.sql.functions import col, concat, current_timestamp, lit

# COMMAND ----------

# MAGIC %md
# MAGIC #####1. Read the json file using spark dataframe reader

# COMMAND ----------

display(dbutils.fs.ls('mnt/f1accstorage/raw'))

# COMMAND ----------

results_stg = spark.read.option("header", True).json('/mnt/f1accstorage/raw/results.json')
display(results_stg)

# COMMAND ----------

results_schema = StructType(fields=[StructField("resultId", StringType(), True),
                                    StructField("raceId", IntegerType(), True),
                                    StructField("driverId", IntegerType(), True),
                                    StructField("constructorId", IntegerType(), False),
                                    StructField("number", IntegerType(), True),
                                    StructField("grid", IntegerType(), True),
                                    StructField("position", StringType(), True),
                                    StructField("positionText", StringType(), True),
                                    StructField("positionOrder", IntegerType(), True),
                                    StructField("points", DoubleType(), True),
                                    StructField("laps", IntegerType(), True),
                                    StructField("time", StringType(), True),
                                    StructField("milliseconds", StringType(), True),
                                    StructField("fastestLap", IntegerType(), True),
                                    StructField("rank", StringType(), True),
                                    StructField("fastestLapTime", StringType(), True),
                                    StructField("fastestLapSpeed", DoubleType(), True),                                  
                                    StructField("statusId", StringType(), True)
                                    
                            
                            ])

# COMMAND ----------

results_df = spark.read \
    .schema(results_schema) \
    .json('/mnt/f1accstorage/raw/results.json')
display(results_df)

# COMMAND ----------

# MAGIC %md
# MAGIC #####2. Rename the columns
# MAGIC - driverId to driver_id
# MAGIC - driverRef to driver_ref
# MAGIC - add column load date 
# MAGIC - name with concatenation
# MAGIC - drop the unwanted columns

# COMMAND ----------

results_manipulated_df = results_df.withColumnRenamed('resultId','result_id') \
    .withColumnRenamed('raceId', 'race_id') \
    .withColumnRenamed('driverId', 'driver_id') \
    .withColumnRenamed('constructorId', 'constructor_id') \
    .withColumnRenamed('positionText', 'position_text') \
    .withColumnRenamed('positionOrder', 'position_order') \
    .withColumnRenamed('fastestLap', 'fastest_lap') \
    .withColumnRenamed('fastestLapTime', 'fastest_lap_time') \
    .withColumnRenamed('fastestLapSpeed', 'fastest_lap_speed') \
    .withColumn('load_date', current_timestamp()) \
    .drop(col('statusId'))

# COMMAND ----------

display(results_manipulated_df)

# COMMAND ----------

# MAGIC %md
# MAGIC #####3. Save as parquet file and validate

# COMMAND ----------

results_manipulated_df.write.mode('overwrite').partitionBy('race_id').parquet('mnt/f1accstorage/raw/results')

# COMMAND ----------

# MAGIC %fs
# MAGIC ls /mnt/f1accstorage/raw/results

# COMMAND ----------

dbutils.notebook.exit("Success")