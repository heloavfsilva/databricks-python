# Databricks notebook source
# MAGIC %md
# MAGIC ####Ingest drivers json nested file
# MAGIC 1. Read the json file using spark dataframe reader
# MAGIC 1. Manipulate the columns (rename, add, drop)
# MAGIC 1. Save as parquet file and validate 

# COMMAND ----------

from pyspark.sql.types import StructType, StructField, IntegerType, StringType, DateType
from pyspark.sql.functions import col, concat, current_timestamp, lit

# COMMAND ----------

# MAGIC %md
# MAGIC #####1. Read the json file using spark dataframe reader

# COMMAND ----------

display(dbutils.fs.ls("mnt/f1accstorage/raw/"))

# COMMAND ----------

drivers_stg = spark.read.option("header",True).csv("/mnt/f1accstorage/raw/drivers.json")
display(drivers_stg)

# COMMAND ----------

name_schema = StructType(fields=[StructField("forename", StringType(), True),
                                 StructField("surname", StringType(), True)

])

# COMMAND ----------

driver_schema = StructType(fields=[StructField("driverId", IntegerType(), False),
                                   StructField("driverRef", StringType(), True),
                                   StructField("number", IntegerType(), True),
                                   StructField("code", StringType(), True),
                                   StructField("name", name_schema),
                                   StructField("dob", DateType(), True),
                                   StructField("nationality", StringType(), True),
                                   StructField("url", StringType(), True)

])

# COMMAND ----------

driver_df = spark.read \
    .schema(driver_schema) \
    .json("/mnt/f1accstorage/raw/drivers.json")
display(driver_df)

# COMMAND ----------

# MAGIC %md
# MAGIC #####2. Rename the columns
# MAGIC - driverId to driver_id
# MAGIC - driverRef to driver_ref
# MAGIC - add column load date 
# MAGIC - name with concatenation
# MAGIC - drop the unwanted columns

# COMMAND ----------

drivers_manipulated_df = driver_df.withColumnRenamed('driverId','driver_id') \
    .withColumnRenamed('driverRef','driver_ref') \
    .withColumn('load_date', current_timestamp()) \
    .withColumn('name', concat(col('name.forename'), lit(' '), col('name.surname'))) \
    .drop(col('url'))

# COMMAND ----------

display(drivers_manipulated_df)

# COMMAND ----------

# MAGIC %md
# MAGIC #####3. Save as parquet file and validate

# COMMAND ----------

drivers_manipulated_df.write.mode('overwrite').parquet('mnt/f1accstorage/processed/drivers')

# COMMAND ----------

#drivers_manipulated_df.write.mode('overwrite').format("parquet").saveAsTable('db_f1_processed.drivers')

# COMMAND ----------

# MAGIC %fs
# MAGIC ls /mnt/f1accstorage/raw/drivers

# COMMAND ----------

# MAGIC %fs
# MAGIC ls /mnt/f1accstorage/processed

# COMMAND ----------

dbutils.notebook.exit("Success")