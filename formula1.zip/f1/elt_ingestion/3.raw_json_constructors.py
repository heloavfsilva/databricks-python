# Databricks notebook source
# MAGIC %md 
# MAGIC ####Ingest construstors.json file
# MAGIC 1. read the json using spark dataframe reader

# COMMAND ----------

from pyspark.sql.functions import col
from pyspark.sql.functions import current_timestamp, lit, to_timestamp, concat

# COMMAND ----------

constructor_schema = "constructorId INT, constructorRef STRING, name STRING, nationality STRING, url STRING"

# COMMAND ----------

constructor_df = spark.read \
    .schema(constructor_schema) \
    .json("/mnt/f1accstorage/raw/constructors.json")

# COMMAND ----------

constructor_df.printSchema()
display(constructor_df)

# COMMAND ----------

constructor_dropped_df = constructor_df.drop('url')

# COMMAND ----------

display(constructor_dropped_df)

# COMMAND ----------

constructor_final_df = constructor_dropped_df.withColumnRenamed('constructorId','constructor_id') \
    .withColumnRenamed('constructorRef','constructor_ref') \
    .withColumn("load_date", current_timestamp())

# COMMAND ----------

display(constructor_final_df)

# COMMAND ----------

constructor_final_df.write.mode("overwrite").parquet("/mnt/f1accstorage/raw/constructors")

# COMMAND ----------

# MAGIC %fs
# MAGIC ls /mnt/f1accstorage/raw/constructors

# COMMAND ----------

dbutils.notebook.exit("Success")