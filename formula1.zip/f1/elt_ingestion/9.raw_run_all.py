# Databricks notebook source
v_result = dbutils.notebook.run("1.raw_csv_circuits", 0)

# COMMAND ----------

v_result

# COMMAND ----------

v_result = dbutils.notebook.run("2.raw_csv_races", 0)

# COMMAND ----------

v_result

# COMMAND ----------

v_result = dbutils.notebook.run("3.raw_json_constructors", 0)

# COMMAND ----------

v_result

# COMMAND ----------

v_result = dbutils.notebook.run("4.raw_json_nested_drivers", 0)

# COMMAND ----------

v_result

# COMMAND ----------

v_result = dbutils.notebook.run("5.raw_json_results", 0)

# COMMAND ----------

v_result

# COMMAND ----------

v_result = dbutils.notebook.run("6.raw_json_multiline_pitstops", 0)

# COMMAND ----------

v_result

# COMMAND ----------

v_result = dbutils.notebook.run("7.raw_csv_multifile_laptimes", 0)

# COMMAND ----------

v_result

# COMMAND ----------

v_result = dbutils.notebook.run("8.raw_json_multiline_multifile_qualifying", 0)

# COMMAND ----------

v_result