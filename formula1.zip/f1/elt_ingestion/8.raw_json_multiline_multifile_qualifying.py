# Databricks notebook source
# MAGIC %md
# MAGIC ####Ingest pitstops json multi-line and multi-file files
# MAGIC 1. Read the json file using spark dataframe reader
# MAGIC 1. Manipulate the columns (rename, add, drop)
# MAGIC 1. Save as parquet file and validate 

# COMMAND ----------

from pyspark.sql.types import StructType, StructField, IntegerType, StringType, DateType, DoubleType
from pyspark.sql.functions import col, concat, current_timestamp, lit

# COMMAND ----------

# MAGIC %run "../config/path_folder_env"

# COMMAND ----------

# MAGIC %run "../config/common_functions"

# COMMAND ----------

# MAGIC %md
# MAGIC #####1. Read the json file using spark dataframe reader

# COMMAND ----------

display(dbutils.fs.ls(f'{path_folder_raw}/qualifying/'))

# COMMAND ----------

stg_pitstop = spark.read.option("multiline", True).json(f'{path_folder_raw}/qualifying/qualifying_split_1.json')
display(stg_pitstop)

# COMMAND ----------

schema_qualifying = StructType(fields=[StructField("qualifyId", IntegerType() ,False),
                                       StructField("raceId", IntegerType() ,False),
                                       StructField("driverId", IntegerType() ,False),
                                       StructField("constructorId", IntegerType() ,False),
                                       StructField("number", IntegerType() ,False),
                                       StructField("position", IntegerType() ,False),
                                       StructField("q1", StringType() ,False),
                                       StructField("q2", StringType() ,False),
                                       StructField("q3", StringType() ,False)                                                            
                                    ])

# COMMAND ----------

df_qualifying = spark.read \
    .schema(schema_qualifying) \
    .option("multiline", True) \
    .json(f'{path_folder_raw}/qualifying/qualifying_split_*.json')
display(df_qualifying)

# COMMAND ----------

# MAGIC %md
# MAGIC #####2. Manipulate the columns (rename, add, drop)

# COMMAND ----------

df_final = df_qualifying.withColumnRenamed("qualifyId", "qualify_id") \
    .withColumnRenamed("raceId", "race_id") \
    .withColumnRenamed("driverId", "driver_id") \
    .withColumnRenamed("constructorId", "constructor_id")

# COMMAND ----------

df_final = add_load_date(df_final)

# COMMAND ----------

# MAGIC %md
# MAGIC #####3. Save as parquet file and validate

# COMMAND ----------

df_final.write.mode("overwrite").parquet(f'{path_folder_raw}/pitstops')

# COMMAND ----------

# MAGIC %fs
# MAGIC ls /mnt/f1accstorage/raw/pitstops

# COMMAND ----------

dbutils.notebook.exit("Success")