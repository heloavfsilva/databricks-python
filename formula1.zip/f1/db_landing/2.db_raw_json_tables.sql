-- Databricks notebook source
-- MAGIC %md
-- MAGIC ####Create tables for JSON files

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ####create constructors table
-- MAGIC * single line json
-- MAGIC * simples structure

-- COMMAND ----------

USE db_f1_raw;

-- COMMAND ----------

DROP TABLE IF EXISTS db_f1_raw.dim_constructors;

-- COMMAND ----------

CREATE TABLE IF NOT EXISTS db_f1_raw.dim_constructors(
  constructorId INT,
  constructorRef STRING,
  name STRING,
  nationality STRING,
  url STRING
) 
USING json
OPTIONS(path "/mnt/f1accstorage/raw/constructors.json")

-- COMMAND ----------

select * from db_f1_raw.dim_constructors;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ####create drivers table
-- MAGIC * single line json
-- MAGIC * complex structure

-- COMMAND ----------

DROP TABLE IF EXISTS db_f1_raw.dim_drivers;
CREATE TABLE IF NOT EXISTS db_f1_raw.dim_drivers(
  driverId INT,
  driverRef STRING,
  number INT,
  code STRING,
  name STRUCT<forename: STRING, surname: STRING>,
  dob DATE,
  nationality STRING,
  url STRING
)
USING json
OPTIONS(path "/mnt/f1accstorage/raw/drivers.json")

-- COMMAND ----------

select * from db_f1_raw.dim_drivers

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ####create results table
-- MAGIC * single line json
-- MAGIC * simple structure

-- COMMAND ----------

DROP TABLE IF EXISTS db_f1_raw.dim_results;
CREATE TABLE IF NOT EXISTS db_f1_raw.dim_results(
  constructorId INT,
  driverId INT,
  fastestLap STRING,
  fastestLapSpeed STRING,
  fastestLapTime STRING,
  grid INT,
  laps INT,
  milliseconds STRING,
  number STRING,
  points double,
  position STRING,
  positionOrder INT,
  positionText STRING,
  raceId INT,
  rank STRING,
  resultId INT,
  statusId INT,
  time STRING
)
USING json
OPTIONS(path "/mnt/f1accstorage/raw/results.json")

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ####create pitstops table
-- MAGIC * multi line json
-- MAGIC * complex structure

-- COMMAND ----------

DROP TABLE IF EXISTS db_f1_raw.dim_pitstops;
CREATE TABLE IF NOT EXISTS db_f1_raw.dim_pitstops(
driverId INT,
duration STRING,
lap INT,
milliseconds STRING,
raceId INT,
stop INT,
time STRING
)
USING json
OPTIONS(path "/mnt/f1accstorage/raw/pit_stops.json", multiLine true)

-- COMMAND ----------

select * from db_f1_raw.dim_pitstops