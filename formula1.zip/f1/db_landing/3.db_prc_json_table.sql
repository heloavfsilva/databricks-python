-- Databricks notebook source
-- MAGIC %md
-- MAGIC ####Create tables for processed layer

-- COMMAND ----------

desc database db_f1_processed

-- COMMAND ----------

