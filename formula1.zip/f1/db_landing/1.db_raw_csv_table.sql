-- Databricks notebook source
-- MAGIC %md
-- MAGIC ####Create the schema and tables for landing database

-- COMMAND ----------

-- MAGIC %fs
-- MAGIC ls 'mnt/f1accstorage/raw/'

-- COMMAND ----------

DROP TABLE IF EXISTS db_f1_raw.dim_circuits

-- COMMAND ----------

CREATE TABLE IF NOT EXISTS db_f1_raw.dim_circuits (
  circuit_id int,
  circuit_ref STRING,
  name STRING,
  location STRING,
  country STRING,
  lat DOUBLE,
  lng DOUBLE, 
  alt DOUBLE
)
USING parquet
OPTIONS (path '/mnt/f1accstorage/raw/circuits/')

-- COMMAND ----------

SELECT * FROM db_f1_raw.dim_circuits

-- COMMAND ----------

DROP TABLE IF EXISTS db_f1_raw.dim_races

-- COMMAND ----------

CREATE TABLE IF NOT EXISTS db_f1_raw.dim_races (
  race_id INT,
  race_year INT,
  round INT,
  circuit_id INT,
  name STRING,
  date STRING,
  time STRING 
  
)
USING parquet
OPTIONS (path '/mnt/f1accstorage/raw/races/')

-- COMMAND ----------

SELECT * FROM db_f1_raw.dim_races

-- COMMAND ----------

