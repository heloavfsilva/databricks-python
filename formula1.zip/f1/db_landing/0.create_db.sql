-- Databricks notebook source
CREATE DATABASE IF NOT EXISTS db_f1_raw

-- COMMAND ----------

CREATE DATABASE IF NOT EXISTS db_f1_processed
LOCATION "/mnt/f1accstorage/processed"

-- COMMAND ----------

DESC DATABASE db_f1_processed

-- COMMAND ----------

CREATE DATABASE IF NOT EXISTS db_f1_presentation