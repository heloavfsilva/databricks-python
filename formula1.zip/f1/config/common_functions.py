# Databricks notebook source
from pyspark.sql.functions import current_timestamp

def add_load_date(input_df):
    output_df = input_df.withColumn('load_date', current_timestamp())
    return output_df