# Databricks notebook source
path_folder_raw ='/mnt/f1accstorage/raw'
path_folder_processed ='/mnt/f1accstorage/processed'
path_folder_presentation ='/mnt/f1accstorage/presentation'