-- Databricks notebook source
database_host = "devshimanosdp.database.windows.net"
database_port = "1433" 
database_name = "dataservices"
table = "customer.CustomerCampaignEvent" 
user = "dataservices_principal"


input_mkt_campaign.write.jdbc(
     url=f"jdbc:sqlserver://{database_host}:{database_port};database={database_name};user={user};password={user_password};encrypt=true;trustServerCertificate=false;hostNameInCertificate=*.database.windows.net;loginTimeout=30;driver=com.microsoft.sqlserver.jdbc.SQLServerDriver",
     table=table,
     mode='overwrite')