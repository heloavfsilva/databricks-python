-- Databricks notebook source
SELECT *
FROM db_f1_presentation.calculated_race_results;

-- COMMAND ----------

SELECT driver_name, SUM(calculated_points) as total_points
FROM db_f1_presentation.calculated_race_results
group by driver_name
order by total_points desc