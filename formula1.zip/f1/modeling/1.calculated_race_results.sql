-- Databricks notebook source
-- MAGIC %md
-- MAGIC ####Calculated race results
-- MAGIC

-- COMMAND ----------

USE db_f1_processed;

-- COMMAND ----------

--drop table db_f1_presentation.calculated_race_results 

-- COMMAND ----------


CREATE TABLE IF NOT EXISTS db_f1_presentation.calculated_race_results 
AS
SELECT races.race_year,
       constructors.name as team_name,
       drivers.name as driver_name,
       results.position,
       results.points,
       11 - results.position as calculated_points
FROM db_f1_raw.dim_results AS results
JOIN db_f1_raw.dim_drivers AS drivers ON (results.driverId = drivers.driverId)
JOIN db_f1_raw.dim_constructors AS constructors ON (results.constructorId = constructors.constructorId)
JOIN db_f1_raw.dim_races AS races ON (results.raceId = races.race_id)
where results.position <=10


-- COMMAND ----------

SELECT * FROM db_f1_presentation.calculated_race_result;