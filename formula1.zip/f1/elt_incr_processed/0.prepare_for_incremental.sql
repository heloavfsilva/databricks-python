-- Databricks notebook source
drop database if exists db_f1_processed cascade;

-- COMMAND ----------

create database if not exists db_f1_processed
location '/mnt/f1accstorage/processed';

-- COMMAND ----------

drop database if exists db_f1_presentation cascade;

-- COMMAND ----------

create database if not exists db_f1_presentation
location '/mnt/f1accstorage/presetation'