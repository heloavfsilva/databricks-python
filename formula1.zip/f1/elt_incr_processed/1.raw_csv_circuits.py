# Databricks notebook source
# MAGIC %md
# MAGIC ####Ingest Circuits File
# MAGIC #####Read the csv file using spark dataframe reader
# MAGIC 1. import types
# MAGIC 1. check the types and define schema
# MAGIC 1. read the csv
# MAGIC 1. rename the columns
# MAGIC 1. add timestamp and env
# MAGIC 1. delete file in case it exists
# MAGIC 1. write it as parquet
# MAGIC 1. validate if the parquet file was generated
# MAGIC
# MAGIC pre-work:
# MAGIC 1. create app registration and save the app ID as client ID and Tenant ID
# MAGIC 1. create a key for the app and save the value as client secret
# MAGIC 1. create the key vault in azure
# MAGIC 1. create the secretScope in databricks
# MAGIC 1. assign role 'Storage Blob Data Contributor' to the app registred
# MAGIC 1. setup the variables in the python function to access it and mount the storage

# COMMAND ----------

from pyspark.sql.types import StructType, StructField, IntegerType, StringType, DoubleType
from pyspark.sql.functions import col
from pyspark.sql.functions import current_timestamp, lit
from pathlib import Path
import os

# COMMAND ----------

dbutils.widgets.text("p_data_source", "")
v_data_source = dbutils.widgets.get("p_data_source")

# COMMAND ----------

dbutils.widgets.text("p_file_date", "")
v_file_date = dbutils.widgets.get("p_file_date")

# COMMAND ----------

# MAGIC %run "../config/common_functions"

# COMMAND ----------

# MAGIC %run "../config/path_folder_env"

# COMMAND ----------

path_folder_raw

# COMMAND ----------

v_file_date

# COMMAND ----------

#define the schema structure
circuits_schema = StructType(fields=[StructField("circuitId", IntegerType(), False),
                                     StructField("circuitRef", StringType(), True),
                                     StructField("name", StringType(), True),
                                     StructField("location", StringType(), True),
                                     StructField("country", StringType(), True),
                                     StructField("lat", DoubleType(), True),
                                     StructField("lng", DoubleType(), True),
                                     StructField("alt", IntegerType(), True),
                                     StructField("url", StringType(), True)                                 
                                     
])

# COMMAND ----------

#read the file with the schema applied
circuits_df = spark.read\
    .option("header",True)\
    .schema(circuits_schema)\
    .csv(f"{path_folder_raw}/{v_file_date}/._circuits.csv")
display(circuits_df)

# COMMAND ----------

# check the file schema
circuits_df.printSchema()

# COMMAND ----------

#you can use the columns names directly however the limitation is if any manipulation is required
#circuits_selected_df = circuits_df.select("circuitId","circuitRef","name", "location", "country", "lat", "lng", "alt")

# COMMAND ----------

#recommended if you want to manipulate
circuits_selected_df = circuits_df.select(col("circuitId"), col("circuitRef"), col("name"), col("location"), 
                                          col("country"), col("lat"), col("lng"), col("alt"))

# COMMAND ----------

display(circuits_selected_df)

# COMMAND ----------

circuits_renamed_df = circuits_selected_df.withColumnRenamed("circuitId","circuit_id") \
    .withColumnRenamed("circuitRef","circuit_ref") \
    .withColumnRenamed("lat","latitude") \
    .withColumnRenamed("lon", "longitude") \
    .withColumnRenamed("alt", "altitude") \
    .withColumn("data_source", lit(v_data_source)) \
    .withColumn("file_date", lit(v_file_date))

# COMMAND ----------

display(circuits_renamed_df)

# COMMAND ----------

#circuit_timestamp_df = circuits_renamed_df.withColumn("load_date", current_timestamp()) \
#    .withColumn("env",lit("raw"))

# COMMAND ----------

circuits_renamed_df.write.mode("overwrite").format("parquet").saveAsTable("db_f1_processed.circuits")

# COMMAND ----------

# MAGIC %fs
# MAGIC ls /mnt/f1accstorage/processed/circuits

# COMMAND ----------

df = spark.read.parquet("/mnt/f1accstorage/processed/circuits")

# COMMAND ----------

display(df)

# COMMAND ----------

dbutils.notebook.exit("Success")