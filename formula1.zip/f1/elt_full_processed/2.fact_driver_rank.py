# Databricks notebook source
# MAGIC %md
# MAGIC ####Drive Standings

# COMMAND ----------

from pyspark.sql.functions import count, sum, when, col, desc, rank
from pyspark.sql.window import Window

# COMMAND ----------

# MAGIC %run "../config/path_folder_env"

# COMMAND ----------

# MAGIC %run "../config/common_functions"

# COMMAND ----------

df_results = spark.read.parquet(f"{path_folder_processed}/fact_races_results")
display(df_results)

# COMMAND ----------

df_driver_standings = df_results \
    .groupBy("race_year", "driver_name", "driver_nationality", "team") \
    .agg(sum("points").alias("total_points"),
         count(when(col("position") == 1, True)).alias("wins")
    ).orderBy(desc("wins"))

# COMMAND ----------

display(df_driver_standings)

# COMMAND ----------

rank_spec_driver = Window.partitionBy("race_year").orderBy(desc("total_points"), desc("wins"))
df_fact_driver = df_driver_standings.withColumn("rank", rank().over(rank_spec_driver))

# COMMAND ----------

display(df_fact_driver)

# COMMAND ----------

#df_fact_driver.write.mode("overwrite").parquet(f"{path_folder_processed}/fact_driver_rank")
df_fact_driver.write.mode("overwrite").saveAsTable("db_f1_processed.fact_driver_rank")

# COMMAND ----------

# MAGIC %fs
# MAGIC ls 'mnt/f1accstorage/processed'