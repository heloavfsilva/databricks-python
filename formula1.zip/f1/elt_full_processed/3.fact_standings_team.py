# Databricks notebook source
# MAGIC %md
# MAGIC ####Constructors Standings

# COMMAND ----------

from pyspark.sql.functions import count, sum, when, col, desc, rank
from pyspark.sql.window import Window

# COMMAND ----------

# MAGIC %run "../config/path_folder_env"

# COMMAND ----------

# MAGIC %run "../config/common_functions"

# COMMAND ----------

df_results = spark.read.parquet(f"{path_folder_processed}/fact_races_results")
display(df_results)

# COMMAND ----------

df_standings_constructors = df_results \
    .filter("race_year=2020") \
    .groupBy("race_year","team") \
    .agg(sum("points").alias("total_points"),
         count(when(col("position")== 1, True)).alias("wins")
         ).orderBy(desc("wins"))

# COMMAND ----------

rank_spec_driver = Window.partitionBy("race_year").orderBy(desc("total_points"), desc("wins"))
df_fact_standings_team = df_standings_constructors.withColumn("rank", rank().over(rank_spec_driver))

# COMMAND ----------

display(df_fact_standings_team)

# COMMAND ----------

#df_fact_standings_team.write.mode("overwrite").parquet(f"{path_folder_processed}/fact_standings_team")
df_fact_standings_team.write.mode("overwrite").saveAsTable("db_f1_processed.fact_standings_team")

# COMMAND ----------

# MAGIC %fs
# MAGIC ls 'mnt/f1accstorage/processed/fact_standings_team'