# Databricks notebook source
# MAGIC %md
# MAGIC ####Creation of the Fact Results
# MAGIC 1. Fetch the raw parquet from results, circuits, races, drivers, constructors and manipulate the columns
# MAGIC 1. Join the keys and fetch the required for the output

# COMMAND ----------

# MAGIC %md
# MAGIC #### Fetch

# COMMAND ----------

# MAGIC %run "../config/path_folder_env"

# COMMAND ----------

# MAGIC %run "../config/common_functions"

# COMMAND ----------

df_results = spark.read.parquet(f"{path_folder_raw}/results") \
    .withColumnRenamed("time", "race_time")
display(df_results)

# COMMAND ----------

df_circuits = spark.read.parquet(f"{path_folder_raw}/circuits") \
    .withColumnRenamed("name", "circuit_name") \
    .withColumnRenamed("location", "circuit_location")
display(df_circuits)

# COMMAND ----------

df_races = spark.read.parquet(f"{path_folder_raw}/races") \
.withColumnRenamed("name", "race_name") \
.withColumnRenamed("date","race_date")
display(df_races)

# COMMAND ----------

df_drivers = spark.read.parquet(f"{path_folder_raw}/drivers") \
    .withColumnRenamed("name", "driver_name") \
    .withColumnRenamed("number", "driver_number") \
    .withColumnRenamed("nationality", "driver_nationality")
display(df_drivers)

# COMMAND ----------

df_constructors = spark.read.parquet(f"{path_folder_raw}/constructors") \
    .withColumnRenamed("name", "team")
display(df_constructors)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Joins

# COMMAND ----------

df_race_circuits = df_circuits.join(
    df_races, df_circuits.circuit_id == df_races.circuit_id, "inner"
).select(
    df_races.race_id,
    df_races.race_name,
    df_races.race_year,
    df_races.race_date,
    df_circuits.circuit_name,
    df_circuits.circuit_location,
)

# COMMAND ----------

display(df_race_circuits)

# COMMAND ----------

df_results_dim = (
    df_results.join(
        df_drivers, 
        df_results.driver_id == df_drivers.driver_id, 
        "left_outer"
    )
    .join(
        df_constructors,
        df_results.constructor_id == df_constructors.constructor_id,
        "left_outer",
    )
    .join(
        df_race_circuits,
        df_results.race_id == df_race_circuits.race_id,
        "inner",
    )
    .select(
        df_race_circuits.race_year,
        df_race_circuits.race_name,
        df_race_circuits.race_date,
        df_race_circuits.circuit_location,
        df_drivers.driver_name,
        df_drivers.driver_number,
        df_drivers.driver_nationality,
        df_constructors.team,
        df_results.grid,
        df_results.fastest_lap,
        df_results.race_time,
        df_results.points,
        df_results.position
    ).filter(
        "race_year in (2019,2020)"
    ).orderBy(df_results.points.desc())
)

# COMMAND ----------

df_fact_results = add_load_date(df_results_dim)

# COMMAND ----------

display(df_fact_results)

# COMMAND ----------

display(dbutils.fs.ls(f"{path_folder_processed}/fact_races_results"))

# COMMAND ----------

#df_fact_results.write.mode("overwrite").format("parquet").saveAsTable(f"{path_folder_processed}/fact_races_results")
#df_fact_results.write.mode("overwrite").parquet(f"{path_folder_processed}/fact_races_results")
df_fact_results.write.mode("overwrite").saveAsTable("db_f1_processed.fact_races_results")

# COMMAND ----------

# MAGIC %fs
# MAGIC ls 'mnt/f1accstorage/processed/'