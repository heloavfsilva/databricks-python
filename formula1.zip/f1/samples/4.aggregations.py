# Databricks notebook source
# MAGIC %md
# MAGIC ####Agreggations
# MAGIC 1. Count, Count Distinct, Sum, Group by, Rank Over

# COMMAND ----------

from pyspark.sql.functions import count, countDistinct, sum, desc, rank
from pyspark.sql.window import Window

driverRank = Window.partitionBy("race_year").orderBy(desc("total_points"))

# COMMAND ----------

# MAGIC %run "../config/path_folder_env"

# COMMAND ----------

df_agg = spark.read.parquet(f"{path_folder_processed}/results")

# COMMAND ----------

display(df_agg)

# COMMAND ----------

display(df_agg.select(count("*")))

# COMMAND ----------

df_agg.select(count("race_name")).show()

# COMMAND ----------

df_agg.select(countDistinct("race_name")).show()

# COMMAND ----------

df_agg.select(sum("points")).show()

# COMMAND ----------

 df_grouped = df_agg \
     .groupBy("race_year","driver_name") \
     .agg(sum("points").alias("total_points"), countDistinct("race_name").alias("number_of_races")) \
     .orderBy("race_year")

# COMMAND ----------

display(df_grouped)

# COMMAND ----------

df_grouped = df_grouped.withColumn("rank", rank().over(driverRank))

# COMMAND ----------

display(df_grouped)