# Databricks notebook source
# MAGIC %md
# MAGIC #### Access Azure Data Lake using Service Principal
# MAGIC 1. Register Azure AD Application / Service Principal
# MAGIC 1. Generate a secret/password for the application
# MAGIC 1. Set spark config with app/client id 
# MAGIC 1. assign role 'Storage Blob Data Contributor' to data lake

# COMMAND ----------

display(dbutils.secrets.list(scope='f1-proj'))

# COMMAND ----------

#copied from AD > App Registration
# client_id = "38da91e7-84d9-4fd2-931f-4405f30995f6"
# tenant_id = "61516343-5b30-45f5-aa2d-9dd4f920c6e1"

# list the created secrets
# dbutils.secrets.list(scope='f1-scope')
client_id = dbutils.secrets.get(scope='f1-proj',key='f1-proj-client-id')
tenant_id = dbutils.secrets.get(scope='f1-proj',key='f1-proj-tenant-id')


# COMMAND ----------

# copied from AD > Certificates & secrets
# client_secret = "g-98Q~uotl6uMrqiUzVCDRsfNnNwv2QfW6w3Obsm"
client_secret = dbutils.secrets.get(scope='f1-proj',key='f1-proj-client-secret')

# COMMAND ----------

# assign role for the App registred in dbaccstorage > Access Control (IAM)

# COMMAND ----------

spark.conf.set("fs.azure.account.auth.type.f1accstorage.dfs.core.windows.net", "OAuth")
spark.conf.set("fs.azure.account.oauth.provider.type.f1accstorage.dfs.core.windows.net", "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider")
spark.conf.set("fs.azure.account.oauth2.client.id.f1accstorage.dfs.core.windows.net", client_id)
spark.conf.set("fs.azure.account.oauth2.client.secret.f1accstorage.dfs.core.windows.net", client_secret)
spark.conf.set("fs.azure.account.oauth2.client.endpoint.f1accstorage.dfs.core.windows.net", f"https://login.microsoftonline.com/{tenant_id}/oauth2/token")

# COMMAND ----------

display(dbutils.fs.ls("abfss://raw@f1accstorage.dfs.core.windows.net"))

# COMMAND ----------

display(spark.read.csv("abfss://raw@f1accstorage.dfs.core.windows.net/circuits.csv"))