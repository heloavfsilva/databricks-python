# Databricks notebook source
# MAGIC %md
# MAGIC #### Spark transformations

# COMMAND ----------

# MAGIC %run "../config/path_folder_env"

# COMMAND ----------

circuits_df = spark.read.parquet(f"{path_folder_raw}/circuits") \
    .filter("circuit_id < 70") \
    .withColumnRenamed("name", "circuit_name")

# COMMAND ----------

races_df = spark.read.parquet(f"{path_folder_raw}/races") \
    .filter("race_year = 2019") \
    .withColumnRenamed("name", "race_name")

# COMMAND ----------

display(circuits_df)

# COMMAND ----------

display(races_df)

# COMMAND ----------

race_circuits_df= circuits_df.join(races_df, circuits_df.circuit_id == races_df.circuit_id, "inner") \
.select(circuits_df.circuit_name, circuits_df.location, circuits_df.country, races_df.race_name, races_df.round)

# COMMAND ----------

display(race_circuits_df)

# COMMAND ----------

#left_outer keeps the data from the table in the left and bring the data from right where it matchs the key
race_circuits_df= circuits_df.join(races_df, circuits_df.circuit_id == races_df.circuit_id, "left_outer") \
.select(circuits_df.circuit_name, circuits_df.location, circuits_df.country, races_df.race_name, races_df.round)

# COMMAND ----------

display(race_circuits_df)

# COMMAND ----------

#right_outer keeps the data from the table in the right and bring the data from left where it matchs the key
race_circuits_df= circuits_df.join(races_df, circuits_df.circuit_id == races_df.circuit_id, "right_outer") \
.select(circuits_df.circuit_name, circuits_df.location, circuits_df.country, races_df.race_name, races_df.round)

# COMMAND ----------

display(race_circuits_df)

# COMMAND ----------

#full_outer, gives a combination of both and fill in the blanks where it don't find the match
race_circuits_df= circuits_df.join(races_df, circuits_df.circuit_id == races_df.circuit_id, "full_outer") \
.select(circuits_df.circuit_name, circuits_df.location, circuits_df.country, races_df.race_name, races_df.round)

# COMMAND ----------

display(race_circuits_df)

# COMMAND ----------

#semi_join is a inner join but you get the columns from the left only
race_circuits_df= circuits_df.join(races_df, circuits_df.circuit_id == races_df.circuit_id, "semi") \
.select(circuits_df.circuit_name, circuits_df.location, circuits_df.country)

# COMMAND ----------

display(race_circuits_df)

# COMMAND ----------

#anti_join is the opposite of the semi, it gets the columns from the right which is not found in the left
race_circuits_df= races_df.join(circuits_df, circuits_df.circuit_id == races_df.circuit_id, "anti")

# COMMAND ----------

display(race_circuits_df)

# COMMAND ----------

#cross_join each record on the left joins with each to the right and return the cartasian product of the two 
race_circuits_df= races_df.crossJoin(circuits_df)


# COMMAND ----------

display(race_circuits_df)

# COMMAND ----------

race_circuits_df.count()