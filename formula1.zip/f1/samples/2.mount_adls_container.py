# Databricks notebook source
# MAGIC %md
# MAGIC #### Mount Azure Data Lake Containers for the Project
# MAGIC 1. create a python function

# COMMAND ----------

def mount_adls(storage_acc_name, container_name):
    # get secrets from Key Vault
    client_id = dbutils.secrets.get(scope='f1-proj',key='f1-proj-client-id')
    tenant_id = dbutils.secrets.get(scope='f1-proj',key='f1-proj-tenant-id')
    client_secret = dbutils.secrets.get(scope='f1-proj',key='f1-proj-client-secret')

    # set spark configurations
    configs = {"fs.azure.account.auth.type": "OAuth",
              "fs.azure.account.oauth.provider.type": "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider",
              "fs.azure.account.oauth2.client.id": client_id,
              "fs.azure.account.oauth2.client.secret": client_secret,
              "fs.azure.account.oauth2.client.endpoint": f"https://login.microsoftonline.com/{tenant_id}/oauth2/token"}
    
    # unmount if already mounted
    if any(mount.mountPoint == f"/mnt/{storage_acc_name}/{container_name}" for mount in dbutils.fs.mounts()):
        dbutils.fs.unmount(f"/mnt/{storage_acc_name}/{container_name}")

    #mount the storage account container
    dbutils.fs.mount(
    source = f"abfss://{container_name}@{storage_acc_name}.dfs.core.windows.net/",
    mount_point = f"/mnt/{storage_acc_name}/{container_name}",
    extra_configs = configs)
    display(dbutils.fs.mounts())

# COMMAND ----------

mount_adls('f1accstorage', 'raw')

# COMMAND ----------

display(spark.read.csv("/mnt/f1accstorage/raw/circuits.csv"))

# COMMAND ----------

# MAGIC %fs
# MAGIC ls /mnt/f1accstorage/raw

# COMMAND ----------

