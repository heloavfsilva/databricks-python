# Databricks notebook source
# MAGIC %md
# MAGIC ####Ingest pitstops csv multi-file files
# MAGIC 1. Read the csv files using spark dataframe reader
# MAGIC 1. Manipulate the columns (rename, add, drop)
# MAGIC 1. Save as parquet file and validate 

# COMMAND ----------

from pyspark.sql.types import StructType, StructField, IntegerType, StringType, DateType, DoubleType
from pyspark.sql.functions import col, concat, current_timestamp, lit

# COMMAND ----------

# MAGIC %md
# MAGIC #####1. Read the csv multi-file using spark dataframe reader

# COMMAND ----------

# MAGIC %md
# MAGIC #####2. Manipulate the columns (rename, add, drop)

# COMMAND ----------

# MAGIC %md
# MAGIC #####3. Save as parquet file and validate 