-- Databricks notebook source
-- MAGIC %md
-- MAGIC ###Create Databases and Objects
-- MAGIC 1. Spark SQL Documentation
-- MAGIC 1. Create demo db
-- MAGIC 1. Data tab UI
-- MAGIC 1. Show and Describe
-- MAGIC 1. find the current database
-- MAGIC 1. create managed tables using Python
-- MAGIC 1. create managed trables using SQL
-- MAGIC 1. effect of dropping a managed table
-- MAGIC 1. describe table
-- MAGIC

-- COMMAND ----------

-- MAGIC %python
-- MAGIC from pyspark.sql.functions import count, countDistinct, sum, desc, rank
-- MAGIC from pyspark.sql.window import Window
-- MAGIC

-- COMMAND ----------

-- MAGIC %run "../config/path_folder_env"

-- COMMAND ----------

CREATE DATABASE IF NOT EXISTS demo

-- COMMAND ----------

SHOW DATABASES

-- COMMAND ----------

DESC DATABASE EXTENDED demo

-- COMMAND ----------

SELECT current_database()

-- COMMAND ----------

USE demo

-- COMMAND ----------

-- MAGIC %python
-- MAGIC df_results = spark.read.parquet(f"{path_folder_processed}/fact_races_results")

-- COMMAND ----------

-- MAGIC %python
-- MAGIC df_results.write.format("parquet").saveAsTable("demo.py_fact_races_results")

-- COMMAND ----------

SHOW TABLES

-- COMMAND ----------

DESC EXTENDED py_fact_races_results

-- COMMAND ----------

SELECT * FROM demo.py_fact_races_results

-- COMMAND ----------

USE db_f1_processed

-- COMMAND ----------

SHOW TABLES