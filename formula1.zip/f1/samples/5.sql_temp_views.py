# Databricks notebook source
# MAGIC %md
# MAGIC ### Access dataframes using SQL
# MAGIC steps:
# MAGIC 1. create temporary views on dataframes
# MAGIC 1. access the views from SQL cell
# MAGIC 1. access the view from Python cell

# COMMAND ----------

from pyspark.sql.functions import count, countDistinct, sum, desc, rank
from pyspark.sql.window import Window


# COMMAND ----------

# MAGIC %run "../config/path_folder_env"

# COMMAND ----------

df_results = spark.read.parquet(f"{path_folder_processed}/fact_races_results")

# COMMAND ----------

df_results.createOrReplaceTempView("v_race_results")

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from v_race_results
# MAGIC where race_year = 2020

# COMMAND ----------

df_v_race_result = spark.sql("select * from v_race_results where race_year=2019")

# COMMAND ----------

display(df_v_race_result)

# COMMAND ----------

df_results.createOrReplaceGlobalTempView("gv_race_results")

# COMMAND ----------

# MAGIC %sql
# MAGIC show tables in global_temp 

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from global_temp.gv_race_results